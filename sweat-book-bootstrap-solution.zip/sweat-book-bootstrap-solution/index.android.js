import { AppRegistry } from 'react-native';
import { Root } from './src';

AppRegistry.registerComponent('SweatBook', () => Root);
