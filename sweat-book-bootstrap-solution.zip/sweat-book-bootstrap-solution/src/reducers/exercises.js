import { exercises as initState } from '../initialState';

export const exercises = (state = initState, { type, payload }) => {
  return state;
};
