# Sweatbook
> react-native app

- `npm install`
